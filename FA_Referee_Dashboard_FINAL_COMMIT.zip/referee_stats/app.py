from flask import Flask, render_template, request, redirect, session, g, flash
import sqlite3
import os
from functools import wraps
import json

app = Flask(__name__)
app.secret_key = 'your_secret_key'
DATABASE = 'referee.db'


# Connect to database
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()


# Admin route protection
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin'):
            flash("Admin access required.", "error")
            return redirect('/admin_login')
        return f(*args, **kwargs)

    return decorated_function


_LOTG_CACHE = None


def load_lotg():
    global _LOTG_CACHE
    if _LOTG_CACHE is None:
        with open('data/lotg.json', 'r', encoding='utf-8') as f:
            _LOTG_CACHE = json.load(f)
    return _LOTG_CACHE


def simple_search_lotg(query):
    data = load_lotg()
    q = query.strip().lower()
    if not q:
        return []

    scored = []
    for item in data:
        text = (item.get('text') or '').lower()
        tags = ' '.join(item.get('tags') or []).lower()
        hay = text + ' ' + tags

        if q in hay:
            # basic score: occurrences in text count a bit more than in tags
            score = text.count(q) * 2 + tags.count(q)
            scored.append((score, item))

    # sort best first
    scored.sort(key=lambda x: x[0], reverse=True)
    return [it for _, it in scored]


# Home route
@app.route('/')
def home():
    return redirect('/login')


# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "error")
            return redirect('/register')

        db = get_db()
        try:
            db.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            db.commit()
            flash("Registration successful. Please log in.", "success")
            return redirect('/login')
        except sqlite3.IntegrityError:
            flash("Username already exists.", "error")
            return redirect('/register')
    return render_template('register.html')


# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password)).fetchone()

        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash("Login successful.", "success")
            return redirect('/dashboard')
        else:
            flash("Invalid credentials.", "error")
            return redirect('/login')
    return render_template('login.html')


# Logout route
@app.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect('/login')


# Dashboard route
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect('/login')
    return render_template('dashboard.html', username=session['username'])


# Add Game route
@app.route('/add_game', methods=['GET', 'POST'])
def add_game():
    if 'user_id' not in session:
        return redirect('/login')

    if request.method == 'POST':
        level = request.form['level']
        position = request.form['position']
        user_id = session['user_id']

        db = get_db()
        db.execute("INSERT INTO games (user_id, level, position) VALUES (?, ?, ?)",
                   (user_id, level, position))
        db.commit()
        flash("Game added successfully.", "success")
        return redirect('/dashboard')

    return render_template('add_game.html')


# Add Sanction route - UPDATED TO HANDLE PLAYER NAMES
@app.route('/add_sanction', methods=['GET', 'POST'])
def add_sanction():
    if 'user_id' not in session:
        return redirect('/login')

    db = get_db()
    game = db.execute("SELECT id, level, position FROM games WHERE user_id = ? ORDER BY id DESC LIMIT 1",
                      (session['user_id'],)).fetchone()

    if not game:
        flash("Please add a game first.", "error")
        return redirect('/add_game')

    if request.method == 'POST':
        player_name = request.form['player_name']
        team_name = request.form['team_name']
        card_type = request.form['type']
        code = request.form.get('yc_code') if card_type == 'Yellow' else request.form.get('rc_code')
        description = f"{card_type} Card - {code}"

        db.execute(
            "INSERT INTO sanctions (user_id, game_id, player_name, team_name, type, code, description) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (session['user_id'], game['id'], player_name, team_name, card_type, code, description))
        db.commit()
        flash("Sanction submitted.", "success")
        return redirect('/dashboard')

    return render_template('add_sanction.html', game=game)


# Team Analysis route
@app.route('/team_analysis', methods=['GET', 'POST'])
def team_analysis():
    if 'user_id' not in session:
        return redirect('/login')

    db = get_db()

    # Get all unique leagues from games table
    leagues = db.execute("""
                         SELECT DISTINCT level
                         FROM games
                         ORDER BY level
                         """).fetchall()

    yellow_cards = []
    red_cards = []
    selected_league = None

    if request.method == 'POST':
        selected_league = request.form.get('league')

        if selected_league:
            # Get yellow card statistics with most common reason codes
            yellow_cards = db.execute("""
                                      SELECT s.player_name,
                                             s.team_name,
                                             COUNT(s.id)          as card_count,
                                             GROUP_CONCAT(s.code) as all_codes
                                      FROM sanctions s
                                               JOIN games g ON s.game_id = g.id
                                      WHERE g.level = ?
                                        AND s.type = 'Yellow'
                                        AND s.player_name IS NOT NULL
                                        AND s.player_name != ''
                                      GROUP BY s.player_name, s.team_name
                                      ORDER BY card_count DESC
                                          LIMIT 10
                                      """, (selected_league,)).fetchall()

            # Get red card statistics with most common reason codes
            red_cards = db.execute("""
                                   SELECT s.player_name,
                                          s.team_name,
                                          COUNT(s.id)          as card_count,
                                          GROUP_CONCAT(s.code) as all_codes
                                   FROM sanctions s
                                            JOIN games g ON s.game_id = g.id
                                   WHERE g.level = ?
                                     AND s.type = 'Red'
                                     AND s.player_name IS NOT NULL
                                     AND s.player_name != ''
                                   GROUP BY s.player_name, s.team_name
                                   ORDER BY card_count DESC
                                       LIMIT 10
                                   """, (selected_league,)).fetchall()

            # Process the codes to show the most common ones
            def process_card_data(cards):
                processed = []
                for card in cards:
                    codes_list = card['all_codes'].split(',') if card['all_codes'] else []
                    # Count frequency of each code
                    code_counts = {}
                    for code in codes_list:
                        code_counts[code] = code_counts.get(code, 0) + 1

                    # Get the most common codes (up to 3)
                    sorted_codes = sorted(code_counts.items(), key=lambda x: x[1], reverse=True)[:3]
                    top_codes = [f"{code} ({count})" for code, count in sorted_codes]

                    processed.append({
                        'player_name': card['player_name'],
                        'team_name': card['team_name'],
                        'card_count': card['card_count'],
                        'top_codes': ', '.join(top_codes) if top_codes else 'N/A'
                    })
                return processed

            yellow_cards = process_card_data(yellow_cards)
            red_cards = process_card_data(red_cards)

    return render_template('team_analysis.html',
                           leagues=leagues,
                           yellow_cards=yellow_cards,
                           red_cards=red_cards,
                           selected_league=selected_league)


# Statistics route
@app.route('/statistics')
def statistics():
    if 'user_id' not in session:
        return redirect('/login')

    db = get_db()
    uid = session['user_id']

    total_games = db.execute("SELECT COUNT(*) FROM games WHERE user_id = ?", (uid,)).fetchone()[0]
    total_yellow = \
    db.execute("SELECT COUNT(*) FROM sanctions WHERE user_id = ? AND type = 'Yellow'", (uid,)).fetchone()[0]
    total_red = db.execute("SELECT COUNT(*) FROM sanctions WHERE user_id = ? AND type = 'Red'", (uid,)).fetchone()[0]

    avg_yellow = round(total_yellow / total_games, 2) if total_games else 0
    avg_red = round(total_red / total_games, 2) if total_games else 0

    leaderboard = db.execute("""
                             SELECT level, COUNT(*) as count
                             FROM games
                             WHERE user_id = ?
                             GROUP BY level
                             ORDER BY count DESC
                                 LIMIT 10
                             """, (uid,)).fetchall()

    yellow_breakdown = db.execute("""
                                  SELECT code, COUNT(*) as count
                                  FROM sanctions
                                  WHERE user_id = ? AND type = 'Yellow'
                                  GROUP BY code
                                  ORDER BY count DESC
                                  """, (uid,)).fetchall()

    red_breakdown = db.execute("""
                               SELECT code, COUNT(*) as count
                               FROM sanctions
                               WHERE user_id = ? AND type = 'Red'
                               GROUP BY code
                               ORDER BY count DESC
                               """, (uid,)).fetchall()

    return render_template('statistics.html',
                           avg_yellow=avg_yellow,
                           avg_red=avg_red,
                           total_yellow=total_yellow,
                           total_red=total_red,
                           leaderboard=leaderboard,
                           yellow_breakdown=yellow_breakdown,
                           red_breakdown=red_breakdown)


# Admin login
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        password = request.form.get('password')
        if password == 'mrfenwickiscool':
            session['admin'] = True
            flash("Admin login successful.", "success")
            return redirect('/admin')
        else:
            flash("Incorrect password.", "error")
            return redirect('/admin_login')
    return render_template('admin_login.html')


# Admin statistics for a referee
@app.route('/admin_statistics/<int:user_id>')
@admin_required
def admin_statistics(user_id):
    db = get_db()

    total_games = db.execute("SELECT COUNT(*) FROM games WHERE user_id = ?", (user_id,)).fetchone()[0]
    total_yellow = \
    db.execute("SELECT COUNT(*) FROM sanctions WHERE user_id = ? AND type = 'Yellow'", (user_id,)).fetchone()[0]
    total_red = db.execute("SELECT COUNT(*) FROM sanctions WHERE user_id = ? AND type = 'Red'", (user_id,)).fetchone()[
        0]

    avg_yellow = round(total_yellow / total_games, 2) if total_games else 0
    avg_red = round(total_red / total_games, 2) if total_games else 0

    leaderboard = db.execute("""
                             SELECT level, COUNT(*) as count
                             FROM games
                             WHERE user_id = ?
                             GROUP BY level
                             ORDER BY count DESC
                                 LIMIT 10
                             """, (user_id,)).fetchall()

    yellow_breakdown = db.execute("""
                                  SELECT code, COUNT(*) as count
                                  FROM sanctions
                                  WHERE user_id = ? AND type = 'Yellow'
                                  GROUP BY code
                                  ORDER BY count DESC
                                  """, (user_id,)).fetchall()

    red_breakdown = db.execute("""
                               SELECT code, COUNT(*) as count
                               FROM sanctions
                               WHERE user_id = ? AND type = 'Red'
                               GROUP BY code
                               ORDER BY count DESC
                               """, (user_id,)).fetchall()

    return render_template('statistics.html',
                           avg_yellow=avg_yellow,
                           avg_red=avg_red,
                           total_yellow=total_yellow,
                           total_red=total_red,
                           leaderboard=leaderboard,
                           yellow_breakdown=yellow_breakdown,
                           red_breakdown=red_breakdown)


@app.route('/admin_statistics', methods=['GET'])
@admin_required
def admin_statistics_redirect():
    user_id = request.args.get('user_id', type=int)
    if user_id:
        return redirect(f'/admin_statistics/{user_id}')
    flash("Please select a valid referee.", "error")
    return redirect('/admin')


@app.route('/admin')
@admin_required
def admin_dashboard():
    db = get_db()
    referees = db.execute("SELECT id, username FROM users").fetchall()
    return render_template('admin_dashboard.html', referees=referees)


# Admin details route
@app.route('/admin_details', methods=['POST'])
@admin_required
def admin_details():
    user_id = request.form.get('user_id')
    admin_pass = request.form.get('admin_pass')

    # Check admin password for sensitive details (different from general admin login)
    if admin_pass != 'superadmin2025':
        flash("Incorrect admin code for viewing details.", "error")
        return redirect('/admin')

    if not user_id:
        flash("Please select a referee.", "error")
        return redirect('/admin')

    db = get_db()

    # Get referee details
    referee = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()

    if not referee:
        flash("Referee not found.", "error")
        return redirect('/admin')

    # Get referee's games and sanctions
    games = db.execute("""
                       SELECT level, position, COUNT(*) as count
                       FROM games
                       WHERE user_id = ?
                       GROUP BY level, position
                       ORDER BY count DESC
                       """, (user_id,)).fetchall()

    sanctions = db.execute("""
                           SELECT s.*, g.level
                           FROM sanctions s
                                    JOIN games g ON s.game_id = g.id
                           WHERE s.user_id = ?
                           ORDER BY s.id DESC LIMIT 20
                           """, (user_id,)).fetchall()

    return render_template('admin_details.html',
                           referee=referee,
                           games=games,
                           sanctions=sanctions)


# Admin league officials route
@app.route('/admin_league_officials', methods=['GET'])
@admin_required
def admin_league_officials():
    league = request.args.get('league')

    if not league:
        flash("Please select a league.", "error")
        return redirect('/admin')

    db = get_db()

    # Get officials who have worked in this league
    officials = db.execute("""
                           SELECT u.username, u.id, COUNT(g.id) as matches_officiated
                           FROM users u
                                    JOIN games g ON u.id = g.user_id
                           WHERE g.level = ?
                           GROUP BY u.id, u.username
                           ORDER BY matches_officiated DESC
                           """, (league,)).fetchall()

    return render_template('admin_league_officials.html',
                           league=league,
                           officials=officials)

# Admin - Most Sanctions (with show all option)
@app.route('/admin_most_sanctions')
@admin_required
def admin_most_sanctions():
    db = get_db()
    show_all = request.args.get('all', default='0') == '1'

    limit_clause = "" if show_all else "LIMIT 10"

    yellow_refs = db.execute(f"""
        SELECT u.username, u.id, COUNT(s.id) as yellow_count
        FROM sanctions s
                 JOIN users u ON s.user_id = u.id
        WHERE s.type = 'Yellow'
        GROUP BY s.user_id
        ORDER BY yellow_count DESC
        {limit_clause}
    """).fetchall()

    red_refs = db.execute(f"""
        SELECT u.username, u.id, COUNT(s.id) as red_count
        FROM sanctions s
                 JOIN users u ON s.user_id = u.id
        WHERE s.type = 'Red'
        GROUP BY s.user_id
        ORDER BY red_count DESC
        {limit_clause}
    """).fetchall()

    return render_template('admin_most_sanctions.html',
                           yellow_refs=yellow_refs,
                           red_refs=red_refs,
                           show_all=show_all)


# LOTG advice route (search)
@app.route('/lotg', methods=['GET', 'POST'])
def lotg():
    results = []
    query = None
    if request.method == 'POST':
        query = request.form.get('keywords', '')
        results = simple_search_lotg(query)
    return render_template('lotg.html', results=results, query=query)


# Initialize DB if missing
if __name__ == '__main__':
    if not os.path.exists(DATABASE):
        with sqlite3.connect(DATABASE) as db:
            with open('schema.sql') as f:
                db.executescript(f.read())
    app.run(debug=True)
